<?php
$_lang['smschook'] = 'smschook';
$_lang['setting_smschook_login'] = 'SmscRu Login';
$_lang['setting_smschook_password'] = 'SmscRu Password';
$_lang['setting_smschook_phones'] = 'SmscRu Phones (format without + and any other symbols)';