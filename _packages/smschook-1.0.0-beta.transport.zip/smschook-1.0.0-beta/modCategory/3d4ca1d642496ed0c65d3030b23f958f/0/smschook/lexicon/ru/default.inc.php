<?php
$_lang['smschook'] = 'smschook';
$_lang['setting_smschook_login'] = 'SmscRu Логин';
$_lang['setting_smschook_password'] = 'SmscRu Пароль';
$_lang['setting_smschook_phones'] = 'SmscRu Телефон (формат без + и других специальных символов)';